#ifndef _GLOBALS_H_
#define _GLOBALS_H_

extern int VERBOSE;
extern double XSMALL;
extern double EPSILON;
extern double TICKS_PER_SECOND;

#endif /* _GLOBALS_H_ */
