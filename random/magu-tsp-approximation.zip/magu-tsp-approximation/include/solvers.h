#ifndef _SOLVERS_H_
#define _SOLVERS_H_

#include "tsp.h"

solution TSPopt(instance inst);

#endif /* _SOLVERS_H_ */
