int VERBOSE = 0;
double XSMALL = 1e5;
double EPSILON = 1e9;
double TICKS_PER_SECOND = 1200.0;
